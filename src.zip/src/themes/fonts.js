export const EXTRA_SMALL = 10;
export const SMALL = 12;
export const MEDIUM = 15;
export const LARGE = 18;
export const EXTRA_LARGE = 22;
